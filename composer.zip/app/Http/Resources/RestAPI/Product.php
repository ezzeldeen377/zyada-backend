<?php

namespace App\Http\Resources\RestAPI;

class Product
{

}
