<?php

namespace App\Enums;

enum SessionKey
{
    const ADMIN_RECAPTCHA_KEY = 'adminRecaptchaSessionKey';
    const VENDOR_RECAPTCHA_KEY = 'sellerRecaptchaSessionKey';
}
