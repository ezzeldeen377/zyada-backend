<?php

namespace App\Enums\ExportFileNames\Admin;

enum Addon
{
    const EXPORT_CSV = 'Addons.csv';
    const EXPORT_XLSX = 'Addons.xlsx';
}
