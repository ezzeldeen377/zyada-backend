<?php

namespace App\Enums\ExportFileNames\Admin;

enum Category
{
    const EXPORT_CSV = 'Categories.csv';
    const EXPORT_XLSX = 'Categories.xlsx';
}
